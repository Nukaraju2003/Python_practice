# create generator function
# def Items():
#     print("First item!")
#     yield 15

#     print("Second item!")
#     yield 25

#     print("Last item!")
#     yield 40

# newGenerat = Items()

# print(next(newGenerat))
# print(next(newGenerat))
# print(next(newGenerat))
# print(next(newGenerat))

# return a value and terminate the execution of the function
# def Items():
#     print("First item!")
#     yield 15

#     return

#     print("Second item!")
#     yield 25

#     print("Last item!")
#     yield 40

# newGenerat = Items()
# print(next(newGenerat))
# print(next(newGenerat))
# print(next(newGenerat))

# Using generator function with for loop
# def newUpTo(x):
#     for i in range(x):
#         yield i

# seq1 = newUpTo(7)
# print(next(seq1)) 
# print(next(seq1)) 
# print(next(seq1)) 
# print(next(seq1)) 
# print(next(seq1)) 
# print(next(seq1)) 
# print(next(seq1)) 
# print(next(seq1)) 

# yield square of number
# def squareSequence(x):
#     for i in range(x):
#         yield i * i

# newGenerat = squareSequence(7)
# while True:
#     try:
#         print("Received on the next(): ", next(newGenerat))
#     except StopIteration:
#         break
# generator with for loop and StopIteration automatically
# for sqr in newGenerat:
#     print(sqr)

# Use generator expression
# newSquare = (i * i for i in range(7))

# print(next(newSquare))   
# print(next(newSquare)) 
# print(next(newSquare)) 
# print(next(newSquare)) 
# print(next(newSquare)) 
# print(next(newSquare)) 
# print(next(newSquare))  
# print(next(newSquare)) 

# pass generator expression in a function
import math
print(sum(i * i for i in range(4)))
