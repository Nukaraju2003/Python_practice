# from newpackage import newfunctions
# print(newfunctions.power(3, 3))

# from newpackage.newfunctions import sum
# print(sum(10 , 20))

from newpackage.newfunctions import average
print(average(30, 20))