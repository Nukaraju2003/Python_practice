from setuptools import setup
setup(name = 'newpackage',
version='0.1',
description='Testing installation of newpackage',
url='#',
author='Ahmed IB',
author_email='',
license='',
packages=['newpackage'],
zip_safe=False)
