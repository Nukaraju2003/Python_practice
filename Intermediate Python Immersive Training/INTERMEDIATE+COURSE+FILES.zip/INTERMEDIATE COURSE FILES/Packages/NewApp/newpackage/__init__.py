from .newfunctions import average, power
from .greeting import greeting

