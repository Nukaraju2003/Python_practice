from newpackage import power, average, greeting

# call greeting function
greeting("Jack")

print("=========================")
# use power function
x = power(5, 2)
print(x)