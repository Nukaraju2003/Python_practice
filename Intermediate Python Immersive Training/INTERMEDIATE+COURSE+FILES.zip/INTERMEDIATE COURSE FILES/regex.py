# import the regular expressions module
# import re

# Search the string to see if it starts with "You" and ends with "Python"
# newTxt = "You can start learning Python now"
# x = re.search("^You.*Python$", newTxt) 

# if x:
#     print("Yes, we have a match!")
# else:
#     print("No match!")
# Use findall and print a list of all matches
# import re

# newTxt = "Python is very very easy to understand"
# x = re.findall("place", newTxt)
# print(x)
# Search for the first white-space
# import re

# newTxt = "Python is very easy"
# x = re.search("\s", newTxt)

# print("First white-space position:", x.start())
# Making a search that returns no match
# import re

# newTxt = "Python is very fun"
# x = re.search("rain", newTxt)
# print(x)
# Split at each white-space inthe string
# import re

# newTxt = "Try to code with Python"
# x = re.split("\s", newTxt, 2)

# print(x)

# replace every white space with $
# import re

# newTxt = "Python is very easy"
# x = re.sub("\s", "$", newTxt, 1)
# print(x)

# search and return a match object
# import re

# newTxt = "Python is very very easy"
# x = re.search("very", newTxt)

# print(x)  # print an object
# import re

# # Searching for upper case C in the beginning of a word and print its position
# newTxt = "Code with Python now"
# x = re.search(r"\bC\w+", newTxt)

# print(x.span())

import re

# string property to return the string passed into the function

newStr = "Python is so good for beginners"
x = re.search(r"\bP\w+", newStr)

# print(x.string)

# Print the word that contains upper case P in the beginning
print(x.group())